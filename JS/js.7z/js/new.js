for(var i=10; i<=20; i++)
{ 
console.log(i);
}	

/*var n=0;
for(var i=10; i<=20; i++)
{ 
n=n+i;
}	
console.log(n);*/