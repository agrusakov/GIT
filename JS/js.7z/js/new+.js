function buttonClick(){
	/*var resultDiv = document.getElementById('result').value='';*/
	var x1 = parseInt(document.getElementById('x1').value);
	var x2 = parseInt(document.getElementById('x2').value);
	if(Number.isNaN(x1) || Number.isNaN(x2)){
		alert("Должны быть введены числовые значения!")
	} else {
	var resultDiv = document.getElementById('result');
		resultDiv.append("x1+x2="+(x1+x2));
	/*x1 = document.getElementById('x1').value='';
	x2 = document.getElementById('x2').value='';*/
 }
}